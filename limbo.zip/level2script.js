const { Engine, Render, Runner, Bodies, Body, Composite, Events } = Matter;

// Create engine
const engine = Engine.create();
const world = engine.world;

// Create renderer
const render = Render.create({
    element: document.body,
    canvas: document.getElementById('gameCanvas'),
    engine: engine,
    options: {
        width: window.innerWidth,
        wireframes:false,
        background: '#0e0e0e'
        
    }

});





Render.run(render);
const runner = Runner.create();
Runner.run(runner, engine);




window.onload = function() {
    const blackOverlay = document.getElementById('blackOverlay');
    
    // Fade out the black screen
    setTimeout(() => {
        blackOverlay.style.opacity = '0';
        
        // Optional: Remove the overlay after fade out
        setTimeout(() => {
            blackOverlay.remove();
        }, 2000); // 2 seconds same as the transition time
    }, 50); // Delay before fade starts
};

// Character and world elements
// Define the character with light properties
const character = Bodies.circle(400, window.innerHeight - 150, 20, { 
    render: { fillStyle: '#fff' },
    light: {
        radius: 150, // Radius of the light effect
        color: 'rgba(255, 255, 255, 0.5)' // Color of the light
    }
});

const ground = Bodies.rectangle(window.innerWidth / 2, window.innerHeight - 50, window.innerWidth * 20, 60, { isStatic: true });
Composite.add(world, [character, ground]);

let score = 0;
const coins = [];
const platforms = [];
let canJump = false; // Track if the character can jump


const totalCoins = 17; // Total number of coins
let collectedCoins = 0; // Number of collected coins
let greenPlatform = null; // Variable to hold the green platform





// Get the overlay canvas and its context
const overlayCanvas = document.getElementById('overlayCanvas');
const overlayContext = overlayCanvas.getContext('2d');

// Set the canvas size to match the window
overlayCanvas.width = window.innerWidth;
overlayCanvas.height = window.innerHeight;

// Example player object (replace with your actual player's coordinates)
const player = {
    x: window.innerWidth / 2, // Replace with actual player's initial X position
    y: window.innerHeight / 2.25, // Replace with actual player's initial Y position
    radius: 15 // Example radius, adjust as per your player size
};

// Function to render the focus light following the player
function renderFocusLight() {
    // Clear the overlay canvas
    overlayContext.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);

    // Create radial gradient at player's position
    const gradient = overlayContext.createRadialGradient(
        player.x, player.y, 10,    // Gradient start (centered on player)
        player.x, player.y, 150   // Gradient end (light radius)
    );

// Set black gradient colors
gradient.addColorStop(0, 'rgba(255, 255, 255, 0.05)');   // Fully transparent
gradient.addColorStop(0.2, 'rgba(0, 0, 0, 0)'); // Fully transparent
gradient.addColorStop(0.4, 'rgba(0, 0, 0, 0)'); // Fully transparent
gradient.addColorStop(0.6, 'rgba(0, 0, 0, 0)'); // Fully transparent
gradient.addColorStop(0.8, 'rgba(0, 0, 0, 0)'); // Fully transparent
gradient.addColorStop(0.85, 'rgba(0, 0, 0, 0.2)'); // Gradually increasing opacity
gradient.addColorStop(0.90, 'rgba(0, 0, 0, 0.4)');
gradient.addColorStop(0.95, 'rgba(0, 0, 0, 0.6)');
gradient.addColorStop(1, 'rgba(0, 0, 0, 0.8)');   
gradient.addColorStop(1, 'rgba(0, 0, 0, 0.95)');// Almost opaque

    // Fill the entire canvas with the gradient
    overlayContext.fillStyle = gradient;
    overlayContext.fillRect(0, 0, overlayCanvas.width, overlayCanvas.height);
}

// Function to update player position (replace with actual movement code)
function updatePlayerPosition(x, y) {
    player.x = x;
    player.y = y;
}

// Game loop to render the light following the player
function gameLoop() {
    renderFocusLight(); // Call the light rendering function
    requestAnimationFrame(gameLoop); // Continue the loop
}

// Start the game loop
gameLoop();






function generateWorld() {
    const platformWidth = 150;
    const platformHeight = 20;
    const coinRadius = 10;
    const positions = [
        { x: window.innerWidth + 200, y: window.innerHeight - 150, width: platformWidth, height:platformHeight,hasCoin: true},
        { x: window.innerWidth + 500, y: window.innerHeight - 150, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 700, y: window.innerHeight - 150, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 900, y: window.innerHeight - 150, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 1100, y: window.innerHeight - 150, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 600, y: window.innerHeight - 300, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 800, y: window.innerHeight - 450, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 600, y: window.innerHeight - 600, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 1000, y: window.innerHeight - 600, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 1250, y: window.innerHeight - 500, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 1450, y: window.innerHeight - 350, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 1650, y: window.innerHeight - 520, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 1770, y: window.innerHeight - 500, width: 20, height:20, hasCoin: true },
        { x: window.innerWidth + 1900, y: window.innerHeight - 510, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 2100, y: window.innerHeight - 610, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 2300, y: window.innerHeight - 550, width: platformWidth, height:platformHeight, hasCoin: true },
        { x: window.innerWidth + 2500, y: window.innerHeight - 340, width: platformWidth, height:platformHeight, hasCoin: true },
        
         // wall <
        { x: window.innerWidth + 2700, y: window.innerHeight - 570, width: 20, height:250, hasCoin: false },
        { x: window.innerWidth + 2700, y: window.innerHeight - 185, width: 20, height: 210, hasCoin: false },
          { x: window.innerWidth + 0, y: window.innerHeight - 700, width: 20, height: 1240, hasCoin: false },
        // wall >
        
        // Add more positions as needed
    ];

    positions.forEach(pos => {
        // Create a platform at each predefined position with specific width
        let platform = Bodies.rectangle(pos.x, pos.y, pos.width, pos.height, { isStatic: true });
        platforms.push(platform);
        Composite.add(world, platform);

// Conditionally create a coin
        if (pos.hasCoin) {
            let coin = Bodies.circle(pos.x, pos.y - platformHeight / 2 - coinRadius, coinRadius, { 
                isStatic: true,
                isSensor: true,
                render: { fillStyle: 'yellow' } 
            });
        coins.push(coin);
        Composite.add(world, coin);
        }
    });
// Create and add green platform
    addgreenPlatform(window.innerWidth + 2700, window.innerHeight - 400);
    
    // Create and add win platform
    addwinPlatform(window.innerWidth + 2720, window.innerHeight - 400);
}





// Function to create a movable platform
function createMovablePlatform(x, y) {
    return Bodies.rectangle(x, y, 100, 20, { 
        isStatic: false,  // Allows the platform to move
        render: { fillStyle: 'blue' }  // Optional: Set the color
    });
}

// Function to manually add a movable platform at a specific position
function addMovablePlatform(x, y) {
    const movablePlatform = createMovablePlatform(x, y);
    platforms.push(movablePlatform);
    Composite.add(world, movablePlatform);
}

// Example usage: Adding a movable platform at a specific position
addMovablePlatform(window.innerWidth + 1655, window.innerHeight - 560);
// Adjust x and y as needed



// green


// Function to create and add a green platform to the Matter.js world
function creategreenPlatform(x, y) {
    return Bodies.rectangle(x, y, 20, 230, { 
        isStatic: true,
        render: { fillStyle: 'green' },
        label: 'greenPlatform'
    });
}

// Function to manually add a green platform at a specific position
function addgreenPlatform(x, y) {
    const greenPlatform = creategreenPlatform(x, y);
    platforms.push(greenPlatform);
    Composite.add(world, greenPlatform);


}

// Remove green platform 

function removeGreenPlatform() {
    // Get all bodies in the world
    const allBodies = Composite.allBodies(world);
    
    // Loop through all bodies to find the 'greenPlatform'
    allBodies.forEach((body) => {
        if (body.label === 'greenPlatform') {
            Composite.remove(world, body);
        }
    });
}



// win


// Function to create and add a win platform to the Matter.js world
function createwinPlatform(x, y) {
    return Bodies.rectangle(x, y, 20, 230, { 
        isStatic: true,
        render: { fillStyle: 'transparent' },
        label: 'winPlatform'
    });
}

// Function to manually add a win platform at a specific position
function addwinPlatform(x, y) {
    const winPlatform = createwinPlatform(x, y);
    platforms.push(winPlatform);
    Composite.add(world, winPlatform);


}



// enemy 

// Function to create a enemy platform
function createenemyPlatform(x, y) {
    return Bodies.rectangle(x, y, 120, 20, { 
        isStatic: true,  // Allows the platform to move
        render: { fillStyle: 'red' },  // Optional: Set the color
    });
}

// Function to manually add a enemy platform at a specific position
function addenemyPlatform(x, y) {
    const enemyPlatform = createenemyPlatform(x, y);
    platforms.push(enemyPlatform);
    Composite.add(world, enemyPlatform);
}

// Example usage: Adding a enemy platform at a specific position
addenemyPlatform(window.innerWidth + 350, window.innerHeight - 150); 
addenemyPlatform(window.innerWidth + 1500, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 1600, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 1700, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 1800, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 1900, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 2000, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 2100, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 2200, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 2350, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 2450, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 2550, window.innerHeight - 100,);
addenemyPlatform(window.innerWidth + 2650, window.innerHeight - 100,);


// Adjust x and y as needed



// Function to create a fake platform
function createfakePlatform(x, y) {
    return Bodies.rectangle(x, y, 100, 20, { 
        isStatic: true, 
        isSensor:true,// Allows the platform to move
        render: { fillStyle: '' }  // Optional: Set the color
    });
}

// Function to manually add a fake platform at a specific position
function addfakePlatform(x, y) {
    const fakePlatform = createfakePlatform(x, y);
    platforms.push(fakePlatform);
    Composite.add(world, fakePlatform);
}

// Example usage: Adding a fake platform at a specific position
addfakePlatform(window.innerWidth + 2650, window.innerHeight - 340); // Adjust x and y as needed



generateWorld();




// Detect collisions between player and win platform
Events.on(engine, 'collisionStart', function(event) {
    event.pairs.forEach(pair => {
        const { bodyA, bodyB } = pair;
        
        // Check if the player collides with the win platform
        if ((bodyA === character && bodyB.label === 'winPlatform') || 
            (bodyB === character && bodyA.label === 'winPlatform')) {
            
            // Trigger fade to black and go to gamewin.html
            fadeToBlackAndWin();
        }
    });
});

// Function to fade to black and then go to gamewin.html
function fadeToBlackAndWin() {
    // Add a full-screen div that will fade to black
    const fadeDiv = document.createElement('div');
    fadeDiv.style.position = 'fixed';
    fadeDiv.style.top = '0';
    fadeDiv.style.left = '0';
    fadeDiv.style.width = '100%';
    fadeDiv.style.height = '100%';
    fadeDiv.style.backgroundColor = 'black';
    fadeDiv.style.opacity = '0';
    fadeDiv.style.transition = 'opacity 1s ease';  // 2 seconds fade effect
    
    document.body.appendChild(fadeDiv);
    
    // Start fade effect
    setTimeout(() => {
        fadeDiv.style.opacity = '1';
    }, 100); // Small delay to ensure fade starts

    // After fade completes, redirect to gamewin.html
    setTimeout(() => {
      location.href = 'gamewin.html';
    }, 1000); // Redirect after 1 seconds (to match fade duration)
}



// Detect collisions between player and enemy platform
Events.on(engine, 'collisionStart', function(event) {
    event.pairs.forEach(pair => {
        const { bodyA, bodyB } = pair;
        
        // Check if the player collides with the enemy platform
        if ((bodyA === character && platforms.includes(bodyB)) || (bodyB === character && platforms.includes(bodyA))) {
            // Check if it's the enemy platform
            if (bodyA.render.fillStyle === 'red' || bodyB.render.fillStyle === 'red') {
                // Trigger fade to black and reset player position
                fadeToBlackAndReset();
            }
        }
    });
});

// Function to fade screen to black and reset the player
function fadeToBlackAndReset() {
    // Create a black overlay
    const overlay = document.createElement('div');
    overlay.style.position = 'absolute';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'black';
    overlay.style.opacity = '0';
    overlay.style.transition = 'opacity 0.5s ease'; // Smooth transition (0.5s)

    document.body.appendChild(overlay);

    // Fade to black slowly (0.5 seconds)
    setTimeout(() => {
        overlay.style.opacity = '1';
    }, 10); // Slight delay to apply transition

    // After 1 second, reset the player and fade back
    setTimeout(() => {
        // Reset player to starting position
        Body.setPosition(character, { x: 400, y: window.innerHeight - 150 });
        
        // Fade back from black slowly (0.5 seconds)
        setTimeout(() => {
            overlay.style.opacity = '0';
        }, 500); // Wait for the black screen for a moment

        // Remove the overlay after fade out
        setTimeout(() => {
            document.body.removeChild(overlay);
        }, 500); // Ensure enough time for the fade-out
    }, 500); // 1 second delay before resetting the player
}




// Detect if character is on the ground or a platform
Events.on(engine, 'collisionStart', function(event) {
    event.pairs.forEach(pair => {
        // Character on ground/platform logic
        if ((pair.bodyA === character && (pair.bodyB === ground || platforms.includes(pair.bodyB))) ||
            (pair.bodyB === character && (pair.bodyA === ground || platforms.includes(pair.bodyA)))) {
            canJump = true;
        }

        // Character collides with coin logic
        coins.forEach((coin, index) => {
            if ((pair.bodyA === character && pair.bodyB === coin) || (pair.bodyB === character && pair.bodyA === coin)) {
                score++;
                document.getElementById('score').innerText = score;
                Composite.remove(world, coin);
                coins.splice(index, 1);
                collectedCoins++;

                if (collectedCoins === totalCoins) {
    removeGreenPlatform();  
    
}
            }
        });
    });
});

// Detect when character leaves the ground or platform (collision end)
Events.on(engine, 'collisionEnd', function (event) {
    event.pairs.forEach(function (pair) {
        if ((pair.bodyA === character && (pair.bodyB === ground || platforms.includes(pair.bodyB))) ||
            (pair.bodyB === character && (pair.bodyA === ground || platforms.includes(pair.bodyA)))) {
            // Set canJump to false if character is no longer touching the ground or platform
            canJump = false;
        }
    });
});

// Control character with buttons
// Variables to track intervals
let leftInterval, rightInterval;

// Left button
function moveLeft() {
    if (character.velocity.x > -2) { // Ensure speed doesn't exceed limit
        Body.applyForce(character, character.position, { x: -0.01, y: 0 }); // Apply small force to move left
       
    }
}
document.getElementById('leftButton').addEventListener('mousedown', () => {
    moveLeft(); // Move initially
    leftInterval = setInterval(moveLeft, 50); // Continue moving while button is pressed
});
document.getElementById('leftButton').addEventListener('touchstart', () => {
    moveLeft(); // Move initially
    leftInterval = setInterval(moveLeft, 50); // Continue moving while button is pressed
});
document.getElementById('leftButton').addEventListener('mouseup', () => {
    clearInterval(leftInterval); // Stop moving
});
document.getElementById('leftButton').addEventListener('touchend', () => {
    clearInterval(leftInterval); // Stop moving
});

// Right button
function moveRight() {
    if (character.velocity.x < 2) { // Ensure speed doesn't exceed limit
        Body.applyForce(character, character.position, { x: 0.01, y: 0 }); // Apply small force to move right
       
    }
}
document.getElementById('rightButton').addEventListener('mousedown', () => {
    moveRight(); // Move initially
    rightInterval = setInterval(moveRight, 50); // Continue moving while button is pressed
});
document.getElementById('rightButton').addEventListener('touchstart', () => {
    moveRight(); // Move initially
    rightInterval = setInterval(moveRight, 50); // Continue moving while button is pressed
});
document.getElementById('rightButton').addEventListener('mouseup', () => {
    clearInterval(rightInterval); // Stop moving
});
document.getElementById('rightButton').addEventListener('touchend', () => {
    clearInterval(rightInterval); // Stop moving
});

// Jump button
document.getElementById('jumpButton').addEventListener('mousedown', () => {
    if (canJump) {
        Body.applyForce(character, character.position, { x: 0, y: -0.05 });
        canJump = false;
    }
});
document.getElementById('jumpButton').addEventListener('touchstart', () => {
    if (canJump) {
        Body.applyForce(character, character.position, { x: 0, y: -0.05 });
        canJump = false;
    }
});

// New left-side jump button
document.getElementById('leftJumpButton').addEventListener('mousedown', () => {
    if (canJump) {
        Body.applyForce(character, character.position, { x: 0, y: -0.05 });
        canJump = false;
    }
});
document.getElementById('leftJumpButton').addEventListener('touchstart', () => {
    if (canJump) {
        Body.applyForce(character, character.position, { x: 0, y: -0.05 });
        canJump = false;
    }
});

// Camera follows character
Events.on(engine, 'afterUpdate', function () {
  
    // Define camera bounds centered on the character
    const bounds = {
        min: { x: character.position.x - window.innerWidth / 2, y: character.position.y - window.innerHeight / 2 },
        max: { x: character.position.x + window.innerWidth / 2, y: character.position.y + window.innerHeight / 2 }
    };

    // Apply bounds to camera
    Render.lookAt(render, bounds);
});

